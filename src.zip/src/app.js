import express from 'express';
import cors from 'cors';
import {PORT} from './config.js';
import routerUser from './usuario/routerUsuario.js';
import routerEmpresa from './empresa/routerEmpresa.js';
import routerCuenta from './planCuenta/routerCuenta.js';
import routerCotizaciones from './cotizaciones/routerCotizaciones.js';
import routerLibroDiario from './libroDiario/routerLibroDiario.js';
import routerLibroMayor from './libroMayor/routerLibroMayor.js';
import routerPatrimonio from './estadosFinancieros/routerEstadoFinanciero.js';
const app= express();



app.get('/',(req,res)=>{
    res.send('hello word backend abencoado')
})
app.use(cors()) // arreglar el problema de especificar problema de cors en especifico
app.use(express.json())
app.use(express.urlencoded({extended:false}))
app.use('/abencoado',routerUser)
app.use('/abencoado',routerEmpresa)
app.use('/abencoado',routerCuenta)
app.use('/abencoado',routerCotizaciones);
app.use('/abencoado',routerLibroDiario);
app.use('/abencoado',routerLibroMayor);
app.use('/abencoado',routerPatrimonio);
app.set('port',PORT)

/*app.listen(app.get('port'),()=>{
    console.log('aplicacion  backend abencoado corriendo en el puerto')
}) */

export default app;